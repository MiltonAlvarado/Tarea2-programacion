package tarea2;
    import java.util.Scanner;
public class Tarea2 {
    
    public static void main(String[] args) {
        
       Scanner entrada=new Scanner(System.in);
        String datos=entrada.nextLine();
      
      char[] arreglo=datos.toCharArray();
      int sum=0;
      String temp= "";
      for (int i=0;i < arreglo.length;i++){
          char c=arreglo[i];
          if(Character.isDigit(c)){
              temp+=c;
          }else {
              if (temp!=""){
                  sum +=Integer.valueOf(temp);
                  temp="";
              }
          }
      }
      if (temp!=""){
          sum+=Integer.valueOf(temp);
      }
        System.out.println(sum);
    }
    
}
